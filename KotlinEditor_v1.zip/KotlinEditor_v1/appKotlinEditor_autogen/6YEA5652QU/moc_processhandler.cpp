/****************************************************************************
** Meta object code from reading C++ file 'processhandler.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../KotlinEditor/include/processhandler.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'processhandler.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSProcessHandlerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSProcessHandlerENDCLASS = QtMocHelpers::stringData(
    "ProcessHandler",
    "userInputChanged",
    "",
    "processDone",
    "ProcessHandler*",
    "ph",
    "runScript",
    "cwd",
    "script",
    "writeOut",
    "text",
    "terminateEarly",
    "processFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "processError",
    "QProcess::ProcessError",
    "error",
    "processOutputUpdate"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSProcessHandlerENDCLASS_t {
    uint offsetsAndSizes[40];
    char stringdata0[15];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[12];
    char stringdata4[16];
    char stringdata5[3];
    char stringdata6[10];
    char stringdata7[4];
    char stringdata8[7];
    char stringdata9[9];
    char stringdata10[5];
    char stringdata11[15];
    char stringdata12[16];
    char stringdata13[9];
    char stringdata14[21];
    char stringdata15[11];
    char stringdata16[13];
    char stringdata17[23];
    char stringdata18[6];
    char stringdata19[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSProcessHandlerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSProcessHandlerENDCLASS_t qt_meta_stringdata_CLASSProcessHandlerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "ProcessHandler"
        QT_MOC_LITERAL(15, 16),  // "userInputChanged"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 11),  // "processDone"
        QT_MOC_LITERAL(45, 15),  // "ProcessHandler*"
        QT_MOC_LITERAL(61, 2),  // "ph"
        QT_MOC_LITERAL(64, 9),  // "runScript"
        QT_MOC_LITERAL(74, 3),  // "cwd"
        QT_MOC_LITERAL(78, 6),  // "script"
        QT_MOC_LITERAL(85, 8),  // "writeOut"
        QT_MOC_LITERAL(94, 4),  // "text"
        QT_MOC_LITERAL(99, 14),  // "terminateEarly"
        QT_MOC_LITERAL(114, 15),  // "processFinished"
        QT_MOC_LITERAL(130, 8),  // "exitCode"
        QT_MOC_LITERAL(139, 20),  // "QProcess::ExitStatus"
        QT_MOC_LITERAL(160, 10),  // "exitStatus"
        QT_MOC_LITERAL(171, 12),  // "processError"
        QT_MOC_LITERAL(184, 22),  // "QProcess::ProcessError"
        QT_MOC_LITERAL(207, 5),  // "error"
        QT_MOC_LITERAL(213, 19)   // "processOutputUpdate"
    },
    "ProcessHandler",
    "userInputChanged",
    "",
    "processDone",
    "ProcessHandler*",
    "ph",
    "runScript",
    "cwd",
    "script",
    "writeOut",
    "text",
    "terminateEarly",
    "processFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "processError",
    "QProcess::ProcessError",
    "error",
    "processOutputUpdate"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSProcessHandlerENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   62,    2, 0x06,    1 /* Public */,
       3,    1,   63,    2, 0x06,    2 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    2,   66,    2, 0x0a,    4 /* Public */,
       9,    1,   71,    2, 0x0a,    7 /* Public */,
      11,    0,   74,    2, 0x0a,    9 /* Public */,
      12,    2,   75,    2, 0x08,   10 /* Private */,
      16,    1,   80,    2, 0x08,   13 /* Private */,
      19,    0,   83,    2, 0x08,   15 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 14,   13,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ProcessHandler::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSProcessHandlerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSProcessHandlerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSProcessHandlerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ProcessHandler, std::true_type>,
        // method 'userInputChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'processDone'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ProcessHandler *, std::false_type>,
        // method 'runScript'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'writeOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'terminateEarly'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'processFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ExitStatus, std::false_type>,
        // method 'processError'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ProcessError, std::false_type>,
        // method 'processOutputUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ProcessHandler::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ProcessHandler *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->userInputChanged(); break;
        case 1: _t->processDone((*reinterpret_cast< std::add_pointer_t<ProcessHandler*>>(_a[1]))); break;
        case 2: _t->runScript((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->writeOut((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->terminateEarly(); break;
        case 5: _t->processFinished((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QProcess::ExitStatus>>(_a[2]))); break;
        case 6: _t->processError((*reinterpret_cast< std::add_pointer_t<QProcess::ProcessError>>(_a[1]))); break;
        case 7: _t->processOutputUpdate(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ProcessHandler* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ProcessHandler::*)();
            if (_t _q_method = &ProcessHandler::userInputChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ProcessHandler::*)(ProcessHandler * );
            if (_t _q_method = &ProcessHandler::processDone; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *ProcessHandler::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ProcessHandler::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSProcessHandlerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ProcessHandler::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void ProcessHandler::userInputChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void ProcessHandler::processDone(ProcessHandler * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
