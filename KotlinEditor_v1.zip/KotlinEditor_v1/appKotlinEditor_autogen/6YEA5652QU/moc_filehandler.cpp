/****************************************************************************
** Meta object code from reading C++ file 'filehandler.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../KotlinEditor/include/filehandler.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'filehandler.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFileHandlerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFileHandlerENDCLASS = QtMocHelpers::stringData(
    "FileHandler",
    "outputChanged",
    "",
    "isBusyChanged",
    "scriptChanged",
    "inputChanged",
    "text",
    "terminate",
    "setOutput",
    "QString&",
    "getOutput",
    "appendOutput",
    "setIsBusy",
    "busy",
    "getIsBusy",
    "setScript",
    "getScript",
    "terminateProcess",
    "obj",
    "saveFile",
    "output",
    "isBusy",
    "script"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFileHandlerENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[12];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[14];
    char stringdata5[13];
    char stringdata6[5];
    char stringdata7[10];
    char stringdata8[10];
    char stringdata9[9];
    char stringdata10[10];
    char stringdata11[13];
    char stringdata12[10];
    char stringdata13[5];
    char stringdata14[10];
    char stringdata15[10];
    char stringdata16[10];
    char stringdata17[17];
    char stringdata18[4];
    char stringdata19[9];
    char stringdata20[7];
    char stringdata21[7];
    char stringdata22[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFileHandlerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFileHandlerENDCLASS_t qt_meta_stringdata_CLASSFileHandlerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11),  // "FileHandler"
        QT_MOC_LITERAL(12, 13),  // "outputChanged"
        QT_MOC_LITERAL(26, 0),  // ""
        QT_MOC_LITERAL(27, 13),  // "isBusyChanged"
        QT_MOC_LITERAL(41, 13),  // "scriptChanged"
        QT_MOC_LITERAL(55, 12),  // "inputChanged"
        QT_MOC_LITERAL(68, 4),  // "text"
        QT_MOC_LITERAL(73, 9),  // "terminate"
        QT_MOC_LITERAL(83, 9),  // "setOutput"
        QT_MOC_LITERAL(93, 8),  // "QString&"
        QT_MOC_LITERAL(102, 9),  // "getOutput"
        QT_MOC_LITERAL(112, 12),  // "appendOutput"
        QT_MOC_LITERAL(125, 9),  // "setIsBusy"
        QT_MOC_LITERAL(135, 4),  // "busy"
        QT_MOC_LITERAL(140, 9),  // "getIsBusy"
        QT_MOC_LITERAL(150, 9),  // "setScript"
        QT_MOC_LITERAL(160, 9),  // "getScript"
        QT_MOC_LITERAL(170, 16),  // "terminateProcess"
        QT_MOC_LITERAL(187, 3),  // "obj"
        QT_MOC_LITERAL(191, 8),  // "saveFile"
        QT_MOC_LITERAL(200, 6),  // "output"
        QT_MOC_LITERAL(207, 6),  // "isBusy"
        QT_MOC_LITERAL(214, 6)   // "script"
    },
    "FileHandler",
    "outputChanged",
    "",
    "isBusyChanged",
    "scriptChanged",
    "inputChanged",
    "text",
    "terminate",
    "setOutput",
    "QString&",
    "getOutput",
    "appendOutput",
    "setIsBusy",
    "busy",
    "getIsBusy",
    "setScript",
    "getScript",
    "terminateProcess",
    "obj",
    "saveFile",
    "output",
    "isBusy",
    "script"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFileHandlerENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       3,  124, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   98,    2, 0x06,    4 /* Public */,
       3,    0,   99,    2, 0x06,    5 /* Public */,
       4,    0,  100,    2, 0x06,    6 /* Public */,
       5,    1,  101,    2, 0x06,    7 /* Public */,
       7,    0,  104,    2, 0x06,    9 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    1,  105,    2, 0x0a,   10 /* Public */,
      10,    0,  108,    2, 0x0a,   12 /* Public */,
      11,    1,  109,    2, 0x0a,   13 /* Public */,
      12,    1,  112,    2, 0x0a,   15 /* Public */,
      14,    0,  115,    2, 0x0a,   17 /* Public */,
      15,    1,  116,    2, 0x0a,   18 /* Public */,
      16,    0,  119,    2, 0x0a,   20 /* Public */,
      17,    1,  120,    2, 0x0a,   21 /* Public */,

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
      19,    0,  123,    2, 0x02,   23 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9,    6,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QObjectStar,   18,

 // methods: parameters
    QMetaType::Bool,

 // properties: name, type, flags
      20, QMetaType::QString, 0x00015103, uint(0), 0,
      21, QMetaType::Bool, 0x00015103, uint(1), 0,
      22, QMetaType::QString, 0x00015103, uint(2), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject FileHandler::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSFileHandlerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFileHandlerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFileHandlerENDCLASS_t,
        // property 'output'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'isBusy'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'script'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FileHandler, std::true_type>,
        // method 'outputChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'isBusyChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'scriptChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inputChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'terminate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setOutput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'getOutput'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'appendOutput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'setIsBusy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'getIsBusy'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setScript'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'getScript'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'terminateProcess'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        // method 'saveFile'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void FileHandler::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FileHandler *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->outputChanged(); break;
        case 1: _t->isBusyChanged(); break;
        case 2: _t->scriptChanged(); break;
        case 3: _t->inputChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->terminate(); break;
        case 5: _t->setOutput((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1]))); break;
        case 6: { QString _r = _t->getOutput();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->appendOutput((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->setIsBusy((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 9: { bool _r = _t->getIsBusy();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 10: _t->setScript((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 11: { QString _r = _t->getScript();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 12: _t->terminateProcess((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1]))); break;
        case 13: { bool _r = _t->saveFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FileHandler::*)();
            if (_t _q_method = &FileHandler::outputChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FileHandler::*)();
            if (_t _q_method = &FileHandler::isBusyChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FileHandler::*)();
            if (_t _q_method = &FileHandler::scriptChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FileHandler::*)(QString );
            if (_t _q_method = &FileHandler::inputChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (FileHandler::*)();
            if (_t _q_method = &FileHandler::terminate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
    } else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FileHandler *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->getOutput(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->getIsBusy(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getScript(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<FileHandler *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setOutput(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setIsBusy(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setScript(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *FileHandler::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FileHandler::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFileHandlerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int FileHandler::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void FileHandler::outputChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void FileHandler::isBusyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void FileHandler::scriptChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void FileHandler::inputChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void FileHandler::terminate()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}
QT_WARNING_POP
