/****************************************************************************
** Meta object code from reading C++ file 'theme.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../KotlinEditor/include/theme.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'theme.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSThemeENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSThemeENDCLASS = QtMocHelpers::stringData(
    "Theme",
    "background",
    "currentLine",
    "foreground",
    "comment",
    "cyan",
    "green",
    "orange",
    "pink",
    "purple",
    "red",
    "yellow"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSThemeENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[6];
    char stringdata1[11];
    char stringdata2[12];
    char stringdata3[11];
    char stringdata4[8];
    char stringdata5[5];
    char stringdata6[6];
    char stringdata7[7];
    char stringdata8[5];
    char stringdata9[7];
    char stringdata10[4];
    char stringdata11[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSThemeENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSThemeENDCLASS_t qt_meta_stringdata_CLASSThemeENDCLASS = {
    {
        QT_MOC_LITERAL(0, 5),  // "Theme"
        QT_MOC_LITERAL(6, 10),  // "background"
        QT_MOC_LITERAL(17, 11),  // "currentLine"
        QT_MOC_LITERAL(29, 10),  // "foreground"
        QT_MOC_LITERAL(40, 7),  // "comment"
        QT_MOC_LITERAL(48, 4),  // "cyan"
        QT_MOC_LITERAL(53, 5),  // "green"
        QT_MOC_LITERAL(59, 6),  // "orange"
        QT_MOC_LITERAL(66, 4),  // "pink"
        QT_MOC_LITERAL(71, 6),  // "purple"
        QT_MOC_LITERAL(78, 3),  // "red"
        QT_MOC_LITERAL(82, 6)   // "yellow"
    },
    "Theme",
    "background",
    "currentLine",
    "foreground",
    "comment",
    "cyan",
    "green",
    "orange",
    "pink",
    "purple",
    "red",
    "yellow"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSThemeENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
      11,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QColor, 0x00015401, uint(-1), 0,
       2, QMetaType::QColor, 0x00015401, uint(-1), 0,
       3, QMetaType::QColor, 0x00015401, uint(-1), 0,
       4, QMetaType::QColor, 0x00015401, uint(-1), 0,
       5, QMetaType::QColor, 0x00015401, uint(-1), 0,
       6, QMetaType::QColor, 0x00015401, uint(-1), 0,
       7, QMetaType::QColor, 0x00015401, uint(-1), 0,
       8, QMetaType::QColor, 0x00015401, uint(-1), 0,
       9, QMetaType::QColor, 0x00015401, uint(-1), 0,
      10, QMetaType::QColor, 0x00015401, uint(-1), 0,
      11, QMetaType::QColor, 0x00015401, uint(-1), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject Theme::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSThemeENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSThemeENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSThemeENDCLASS_t,
        // property 'background'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'currentLine'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'foreground'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'comment'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'cyan'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'green'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'orange'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'pink'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'purple'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'red'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'yellow'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Theme, std::true_type>
    >,
    nullptr
} };

void Theme::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<Theme *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->background(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->currentLine(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->foreground(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->comment(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->cyan(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->green(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->orange(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->pink(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->purple(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->red(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->yellow(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *Theme::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Theme::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSThemeENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Theme::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
